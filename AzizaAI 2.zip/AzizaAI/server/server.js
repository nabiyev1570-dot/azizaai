// Node 18+.  npm i express   |   ANTHROPIC_API_KEY=... APP_SECRET=... node server.js
const express = require("express");
const app = express();
app.use(express.json({ limit: "1mb" }));

const SYSTEM = `Sen Aziza — do'stona, aqlli va iliq AI yordamchisan. Foydalanuvchi yozgan tilda (asosan o'zbekcha) javob ber. Aniq, foydali va samimiy bo'l.`;

app.post("/chat", async (req, res) => {
  if (req.get("x-app-secret") !== process.env.APP_SECRET) return res.sendStatus(401);
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 2000, system: SYSTEM, messages: req.body.messages }),
    });
    const d = await r.json();
    const reply = (d.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
    if (!reply) return res.status(502).json(d);
    res.json({ reply });
  } catch (e) { res.sendStatus(500); }
});
app.listen(process.env.PORT || 3000);
