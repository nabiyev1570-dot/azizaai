# Aziza AI (iOS, SwiftUI)

## Xcode'da ishga tushirish
1. Xcode → File → New → Project → iOS → App. Name: AzizaAI, Interface: SwiftUI, Language: Swift. Minimum iOS 16.
2. Avtomatik yaratilgan ContentView.swift va AzizaAIApp.swift ni o'chiring.
3. `App/` papkasidagi 6 ta .swift faylni va `Assets.xcassets` ni loyihaga sudrab kiriting (mavjud Assets.xcassets o'rniga).
4. Info.plist: `NSFaceIDUsageDescription` = "Aziza AI ni faqat siz ochishingiz uchun".
5. `Models.swift` da `Config.endpoint` va `appSecret` ni o'zgartiring.

## Server (API kalit shu yerda turadi)
`server/server.js` ni Render / Railway / Fly.io ga joylang. Muhit o'zgaruvchilari: ANTHROPIC_API_KEY, APP_SECRET (ilovadagi bilan bir xil).

## App Store
Apple Developer akkaunti ($99/yil), Bundle ID, Privacy Policy sahifasi, skrinshotlar kerak.
