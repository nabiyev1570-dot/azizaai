import SwiftUI

enum Theme {
    static let accent = Color(red: 0.91, green: 0.25, blue: 0.40)
    static let background = LinearGradient(colors: [Color(red: 0.05, green: 0.06, blue: 0.10), Color(red: 0.16, green: 0.07, blue: 0.14)], startPoint: .top, endPoint: .bottom)
    static let userBubble = LinearGradient(colors: [Color(red: 0.91, green: 0.25, blue: 0.40), Color(red: 0.62, green: 0.20, blue: 0.62)], startPoint: .topLeading, endPoint: .bottomTrailing)
}

struct AvatarView: View {
    var size: CGFloat
    var body: some View {
        Image("Aziza").resizable().scaledToFill()
            .frame(width: size, height: size).clipShape(Circle())
            .overlay(Circle().stroke(Theme.accent, lineWidth: size > 60 ? 3 : 1.5))
            .shadow(color: Theme.accent.opacity(0.5), radius: size / 6)
    }
}
