import SwiftUI

struct ChatView: View {
    @EnvironmentObject var vm: ChatViewModel
    @State private var input = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            if vm.messages.isEmpty { welcome }
                            ForEach(vm.messages) { m in Bubble(message: m).id(m.id) }
                            if vm.isLoading { TypingDots().id("typing") }
                            if let e = vm.error { Text(e).font(.footnote).foregroundStyle(.red) }
                        }.padding()
                    }
                    .scrollDismissesKeyboard(.interactively)
                    .onChange(of: vm.messages) { _ in
                        withAnimation { if let l = vm.messages.last { proxy.scrollTo(l.id, anchor: .bottom) } }
                    }
                    .onChange(of: vm.isLoading) { _ in withAnimation { proxy.scrollTo("typing", anchor: .bottom) } }
                }
                composer
            }
        }
    }

    var header: some View {
        HStack(spacing: 12) {
            AvatarView(size: 44)
            VStack(alignment: .leading, spacing: 2) {
                Text("Aziza AI").font(.system(size: 18, weight: .bold, design: .rounded)).foregroundStyle(.white)
                HStack(spacing: 5) { Circle().fill(.green).frame(width: 7, height: 7); Text("onlayn").font(.caption).foregroundStyle(.white.opacity(0.7)) }
            }
            Spacer()
            Button { vm.clear() } label: { Image(systemName: "trash").foregroundStyle(.white.opacity(0.8)) }
        }
        .padding(.horizontal).padding(.vertical, 10)
        .background(.ultraThinMaterial)
    }

    var welcome: some View {
        VStack(spacing: 14) {
            AvatarView(size: 110)
            Text("Salom! Men Aziza 💫").font(.title2.bold()).foregroundStyle(.white)
            Text("Xohlagan narsangiz haqida so'rang, men shu yerdaman.").multilineTextAlignment(.center).foregroundStyle(.white.opacity(0.7))
        }.padding(.top, 60)
    }

    var composer: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Xabar yozing...", text: $input, axis: .vertical)
                .lineLimit(1...5).focused($focused).foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 22))
            Button {
                let t = input; input = ""
                Task { await vm.send(t) }
            } label: {
                Image(systemName: "arrow.up").font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 44, height: 44).background(Theme.userBubble, in: Circle())
            }
            .disabled(input.trimmingCharacters(in: .whitespaces).isEmpty || vm.isLoading)
        }
        .padding(.horizontal).padding(.vertical, 8).background(.ultraThinMaterial)
    }
}

struct Bubble: View {
    let message: Message
    var isUser: Bool { message.role == "user" }
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if isUser { Spacer(minLength: 50) } else { AvatarView(size: 28) }
            Text(message.text).textSelection(.enabled).foregroundStyle(.white)
                .padding(.horizontal, 14).padding(.vertical, 10)
                .background(isUser ? AnyShapeStyle(Theme.userBubble) : AnyShapeStyle(Color.white.opacity(0.12)), in: RoundedRectangle(cornerRadius: 20))
            if !isUser { Spacer(minLength: 50) }
        }
    }
}

struct TypingDots: View {
    @State private var on = false
    var body: some View {
        HStack(spacing: 8) {
            AvatarView(size: 28)
            HStack(spacing: 5) {
                ForEach(0..<3) { i in
                    Circle().fill(.white.opacity(0.8)).frame(width: 8, height: 8)
                        .scaleEffect(on ? 1 : 0.5).animation(.easeInOut(duration: 0.6).repeatForever().delay(Double(i) * 0.2), value: on)
                }
            }.padding(14).background(.white.opacity(0.12), in: Capsule())
            Spacer()
        }.onAppear { on = true }
    }
}
