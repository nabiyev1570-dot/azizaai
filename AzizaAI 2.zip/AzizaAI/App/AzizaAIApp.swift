import SwiftUI

@main
struct AzizaAIApp: App {
    @StateObject private var lock = LockManager()
    @StateObject private var chat = ChatViewModel()
    var body: some Scene {
        WindowGroup {
            ZStack {
                if lock.unlocked { ChatView().environmentObject(chat) }
                else { LockView().environmentObject(lock) }
            }
            .preferredColorScheme(.dark)
            .onAppear { lock.authenticate() }
        }
    }
}
