import SwiftUI
import LocalAuthentication

/// Face ID / Touch ID / passcode: only the phone owner can open the app.
final class LockManager: ObservableObject {
    @Published var unlocked = false
    func authenticate() {
        let ctx = LAContext()
        var err: NSError?
        guard ctx.canEvaluatePolicy(.deviceOwnerAuthentication, error: &err) else { unlocked = true; return }
        ctx.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Aziza AI ni ochish") { ok, _ in
            DispatchQueue.main.async { self.unlocked = ok }
        }
    }
}

struct LockView: View {
    @EnvironmentObject var lock: LockManager
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 20) {
                AvatarView(size: 120)
                Text("Aziza AI").font(.system(size: 32, weight: .bold, design: .rounded)).foregroundStyle(.white)
                Button { lock.authenticate() } label: {
                    Label("Ochish", systemImage: "faceid").padding(.horizontal, 28).padding(.vertical, 14)
                        .background(Theme.accent, in: Capsule()).foregroundStyle(.white)
                }
            }
        }
    }
}
