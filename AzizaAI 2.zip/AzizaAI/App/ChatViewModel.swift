import SwiftUI

@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [Message] = []
    @Published var isLoading = false
    @Published var error: String?
    private let store = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("chat.json")

    init() {
        if let d = try? Data(contentsOf: store), let m = try? JSONDecoder().decode([Message].self, from: d) { messages = m }
    }
    private func save() { try? JSONEncoder().encode(messages).write(to: store) }
    func clear() { messages = []; save() }

    func send(_ text: String) async {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, !isLoading else { return }
        messages.append(Message(role: "user", text: t)); save()
        isLoading = true; error = nil
        defer { isLoading = false; save() }
        var req = URLRequest(url: Config.endpoint)
        req.httpMethod = "POST"
        req.timeoutInterval = 90
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(Config.appSecret, forHTTPHeaderField: "x-app-secret")
        let payload = ["messages": messages.suffix(40).map { ["role": $0.role, "content": $0.text] }]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            guard (resp as? HTTPURLResponse)?.statusCode == 200,
                  let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let reply = obj["reply"] as? String else { throw URLError(.badServerResponse) }
            messages.append(Message(role: "assistant", text: reply))
        } catch {
            self.error = "Ulanishda xatolik. Qayta urinib ko'ring."
        }
    }
}
