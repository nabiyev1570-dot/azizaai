import Foundation

struct Message: Identifiable, Codable, Equatable {
    var id = UUID()
    let role: String   // "user" | "assistant"
    var text: String
}

enum Config {
    /// Your own server URL (see /server). The API key stays on the server, never in the app.
    static let endpoint = URL(string: "https://YOUR-SERVER.example.com/chat")!
    /// Secret that only your app and your server know.
    static let appSecret = "CHANGE-ME-LONG-RANDOM-STRING"
}
